window.addEventListener('load', function () {
    $(document).ready(function () {



    });
});